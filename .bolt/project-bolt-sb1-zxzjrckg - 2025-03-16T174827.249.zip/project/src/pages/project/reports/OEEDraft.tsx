const OEEDraft: React.FC = () => {
};
export default OEEDraft;